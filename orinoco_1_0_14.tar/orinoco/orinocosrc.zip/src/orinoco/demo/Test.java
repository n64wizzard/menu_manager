/*********************************************************************
*
*      Copyright (C) 2002 Andrew Khan
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
***************************************************************************/

package orinoco.demo;

import java.io.File;
import orinoco.Document;
import orinoco.Heading;
import orinoco.Column;
import orinoco.Font;
import orinoco.Table;
import orinoco.Alignment;
import orinoco.LayoutWriter;
import orinoco.TextWriter;
import orinoco.Paper;
import orinoco.PageNumber;
import orinoco.PostscriptWriter;
import orinoco.PDFWriter;
import orinoco.Colour;
import orinoco.OutputFormatWriter;

public class Test
{
  public static void main(String args[])
  {
    if (args.length != 2 || 
        (!args[0].equals("-ps") && !args[0].equals("-pdf")))
    {
      System.out.println("Usage:  Test -ps|-pdf output");
      System.exit(1);
    }

    try
    {
      OutputFormatWriter ofw = null;

      if (args[0].equals("-ps"))
      {
        ofw = new PostscriptWriter(new File(args[1]));
      }
      else if (args[0].equals("-pdf"))
      {
        ofw = new PDFWriter(new File(args[1]));
      }

      long start = System.currentTimeMillis();

      // Create the document
      Document doc = new Document(Paper.LETTER, ofw);

      // Define a header
      Font titleFont = new Font(Font.HELVETICA_BOLD, 14);
      LayoutWriter header = doc.getHeader();
      //      header.writeLine("orinoco Test Document", titleFont, Alignment.CENTRE);

      Column[] headercols = new Column[4];
      headercols[0] = new  Column(2);
      headercols[1] = new Column(13, Alignment.CENTRE, titleFont);
      headercols[2] = new Column(2, Alignment.RIGHT);
      headercols[3] = new Column(2);

      Table ht = header.createTable(headercols);
      String[] titlerow = new String[]{"col1", 
                                       "orinoco Test Document", 
                                       "page"};
      ht.addCells(titlerow);
      TextWriter w = ht.getCellWriter(3);
      w.writeMacro(new PageNumber(" ", "", doc));
      ht.writeRow();
      ht.close();
      
      header.space(0.2);

      // Define a footer
      Font footerFont = new Font(Font.TIMES, 8);
      LayoutWriter footer= doc.getFooter();
      footer.space(0.1);
      footer.drawLine();
      footer.space(0.1);
      footer.writeMacroLine(new PageNumber("page ", "", doc), 
                            footerFont, Alignment.RIGHT);

      doc.open();
      
      doc.writeLine("Default Font");

      Font f1 = new Font(Font.TIMES_BOLD, 14);
      doc.setFont(f1);
      doc.writeLine("14 point times bold");
      doc.newLine();

      Font f2 = new Font(Font.TIMES_ITALIC, 10);
      doc.setFont(f2);
      doc.writeLine("10 point times italic");

      doc.setFont(Font.DEFAULT);
      doc.writeLine("Back to default");
      doc.newLine();

      Font f3 = new Font(Font.HELVETICA, 13);
      Font f4 = new Font(Font.COURIER, 11);
      Font f5 = new Font(Font.HELVETICA_BOLD, 8);
      doc.writeLine("Various fonts on one line:");

      doc.write("Helvetica 13pt", f3);
      doc.write("Courier 11pt", f4);
      doc.writeLine("Default font");
      doc.drawLine();
      doc.newLine();
      doc.writeLine("This is a very long line, that will take more than " +
                    "one a4 line to display.  Cold are the hands of time " +
                    "that creep along relentlessly, destroying slowly " +
                    "but without pity that which yesterday was young.  " +
                    "Alone our memories resist this disintegration and " +
                    "grow more lovely with the passing years.");
      doc.drawLine();
      doc.writeLine("This is right aligned", Alignment.RIGHT);
      doc.writeLine("This piece of text is also right aligned", 
                    Alignment.RIGHT);
      doc.writeLine("Normal again");
      doc.writeLine("Centred", Alignment.CENTRE);
      doc.newLine();
      doc.writeLine("Some tabs");
      doc.addTab(3);
      doc.addTab(9);
      doc.addTab(11);
      System.out.println("Writing tabs");
      doc.write("Some preamble", f5);
      doc.tab();
      doc.write("tab1");
      doc.tab();
      doc.write("tab2");
      doc.tab();
      doc.write("tab3");
      doc.newLine();
      doc.tab();
      doc.write("another tab");
      doc.tab();
      doc.write("yet another tab");
      doc.newLine();
      doc.writeLine("Not tabbed");
      doc.newLine();
      doc.writeLine("(Text in round brackets)");
      doc.writeLine("(More text in round brackets) outside brackets");
      doc.writeLine("[Text in square brakets]");
      doc.writeLine("{Text in curly brackets}");
      doc.writeLine("Open a single bracket (and write some text");
      doc.writeLine("close the above bracket)");
      doc.newPage();
      doc.writeLine("New page");

      // Create a table
      Font dataFont = new Font(Font.HELVETICA, 8);
      Column col1 = new Column(3, dataFont);
      Column col2 = new Column(3, Alignment.CENTRE, dataFont);
      Column col3 = new Column(4, Alignment.RIGHT, dataFont);
      Column col4 = new Column(2, Alignment.LEFT, dataFont);

      Column[] cols = new Column[] {col1, col2, col3, col4};

      Font tableHeaderFont = new Font(Font.TIMES_BOLD, 13);
      Heading hdr1 = new Heading("Header 1", Alignment.CENTRE, 
                                 tableHeaderFont);
      Heading hdr2 = new Heading("Heading 2", Alignment.CENTRE, 
                                 tableHeaderFont);
      Heading hdr3 = new Heading("Header 3", Alignment.CENTRE, 
                                 tableHeaderFont);
      Heading hdr4 = new Heading("Header 4", Alignment.CENTRE, 
                                 tableHeaderFont);
      
      Heading[] hdrs = new Heading[] {hdr1, hdr2, hdr3, hdr4};

      Table table = doc.createTable(cols, hdrs);
      table.setColumnSpacing(0.25);
      table.setHeaderBackground(Colour.GREY_80);

      String[] firstRow = new String[] {"op(en", "clo)se", "(enclosed)",
                                        "Some (wrapped parentheses)"};
      table.addRow(firstRow);

      for (int i = 0; i < 100; i++)
      {
        String[] data = new String[] {"left " + i, 
                                      "Some data", 
                                      "Some more data", 
                                      "Some wrapped text"};
        table.addRow(data);
      }

      table.close();
      doc.writeLine("The table has ended.  There now follows a table with "+
                    "horizontal borders");
      doc.newLine();

      col1 = new Column(3);
      col2 = new Column(3);
      cols = new Column[] { col1, col2 };
      hdr1 = new Heading("Header 1", Alignment.CENTRE, 
                                 tableHeaderFont);
      hdr2 = new Heading("Heading 2", Alignment.CENTRE, 
                                 tableHeaderFont);
      hdrs = new Heading[] {hdr1, hdr2};

      table = doc.createTable(cols, hdrs);
      table.setRowBorder(1);
      table.setHeaderBackground(Colour.GREY_80);

      for (int i = 0; i < 20 ; i++)
      {
        String[] data = new String[] {"Data item " + i,
                                      "Data value"};
        table.addRow(data);
      }
      table.close();

      doc.writeLine("And now a table demonstrating column spanning and "+
                    "underlining on alternate rows");
      doc.newLine();


      col1 = new Column(3);
      col2 = new Column(3);
      col3 = new Column(3);
      cols = new Column[] { col1, col2, col3 };
      hdr1 = new Heading("Header 1", Alignment.CENTRE, 
                                 tableHeaderFont);
      hdr2 = new Heading("Heading 2", Alignment.CENTRE, 
                                 tableHeaderFont);
      hdr3 = new Heading("Header3", Alignment.CENTRE, 
                         tableHeaderFont);

      hdrs = new Heading[] {hdr1, hdr2, hdr3};

      table = doc.createTable(cols, hdrs);
      table.setHeaderBackground(Colour.GREY_80);

      for (int i = 0; i < 10 ; i++)
      {
        String[] data = new String[] {"Data item " + i,
                                      "Data value", "Data value"};
        table.addRow(data);

        data = new String[] {"Span", null, null};
        table.addCells(data);

        TextWriter tw = table.getCellWriter(1,2);
        tw.write("This text spans two columns");
        table.writeRow();
        
        table.drawLine();
      }
      table.close();


      doc.newPage();
      doc.writeLine("A new page");

      doc.close();
      long stop = System.currentTimeMillis();
      System.out.println("Time taken:  " + (stop - start) + "ms");
    }
    catch (Throwable t)
    {
      t.printStackTrace();
    }
  }
}





